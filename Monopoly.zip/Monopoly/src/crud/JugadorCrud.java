package crud;

public class JugadorCrud {
	
	// METODOS AÑADIR, ELIMINAR, MOSTRAR DATOS DE JUGADOR Y ACTUALIZAR EL DINERO

}
