package crud;

public class CalleCrud {
	
	// METODOS ACTUALIZAR PROPIETARIO DE LA CASILLA Y CREAR CASAS

}
