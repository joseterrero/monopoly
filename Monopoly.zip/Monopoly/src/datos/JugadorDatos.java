package datos;

public class JugadorDatos {
	
	// CONSTRUCTOR DE LA CLASE JUGADOR

}
