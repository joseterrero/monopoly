package controller;

public class DadoController {
	
	// METODOS LANZAR DADOS ALEATORIOS

}
